#include "PlayerPhysics.h"

using namespace std;

Position2D PlayerPhysics::pos() const {
	return Position2D(xPos_, yPos_);
}

void PlayerPhysics::handleInput(const Uint8* inputs) {
	if (inputs[SDL_SCANCODE_A])
		movingLeft();
	else if (inputs[SDL_SCANCODE_D])
		movingRight();
	else//TODO �ڿ��б���x�ٶȣ����������ڿ��лص������ٶȻ��ᱣ�ֲ���
		stopMoving();

	if (inputs[SDL_SCANCODE_K])
		startJump();
	else
		stopJump();
}

void PlayerPhysics::update(units::MS deltaTime) {
	updateX(deltaTime);
	updateY(deltaTime);
#ifdef DEBUG_POS
	if (lastXPos_ != xPos_ || lastYPos_ != yPos_) {
		lastXPos_ = xPos_, lastYPos_ = yPos_;
		cout << xPos_ << " " << yPos_ << endl;
	}
#endif
}

//
void PlayerPhysics::updateX(units::MS deltaTime) {
	units::Game deltaX = round(velocityX_ * deltaTime);
	velocityX_ += accelerationX_ * deltaTime;
	if (accelerationX_ < 0)
		velocityX_ = std::max(velocityX_, -maxVelocityX);
	else if (accelerationX_ > 0)
		velocityX_ = std::min(velocityX_, maxVelocityX);
	else if (onGround_)
		velocityX_ *= slowdown;
	collision_->xCollide(deltaX);
}

void PlayerPhysics::updateY(units::MS deltaTime) {
	const units::Pixel lowest = 288;
	if (!jumping_ && velocityY_ < 0)//��Ծ��;�ſ���Ծ�����Ӵ����µļ��ٶȣ���������Ծ�߶�
		velocityY_ += stopJumpAccelerate * deltaTime;
	else
		velocityY_ += gravity * deltaTime;
	if (velocityY_ > 0)
		jumping_ = false;

	velocityY_ = std::max(velocityY_, -maxVelocityY);
	units::Game deltaY = velocityY_ * deltaTime;
	collision_->yCollide(deltaY);
}

void PlayerPhysics::movingLeft() {
	accelerationX_ = -accelerate;
	stopedmoving_ = false;
}

void PlayerPhysics::movingRight() {
	accelerationX_ = accelerate;
	stopedmoving_ = false;
}

void PlayerPhysics::stopMoving() {
	accelerationX_ = 0;
	stopedmoving_ = true;
}

void PlayerPhysics::startJump() {
	if (onGround_) {
		velocityY_ = -jumpSpeed;
		jumping_ = true;
		onGround_ = false;
	}
}

void PlayerPhysics::stopJump() {
	jumping_ = false;
}